3D models
==========================================================

Edited amethyst rapier
Edited hither thither wand
Edited keeper flamberge
Edited magehunter
Edited spellbreaker

